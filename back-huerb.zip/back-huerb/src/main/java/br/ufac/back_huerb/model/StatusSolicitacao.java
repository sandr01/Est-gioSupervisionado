package br.ufac.back_huerb.model;

public enum StatusSolicitacao {
    PENDENTE,
    APROVADO,
    REJEITADO,
    DEVOLVIDO
}