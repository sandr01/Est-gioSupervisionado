package br.ufac.back_huerb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BackHuerbApplication {

	public static void main(String[] args) {
		SpringApplication.run(BackHuerbApplication.class, args);
		System.out.println("aloooo");
	}

}
